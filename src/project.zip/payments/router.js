'use strict';

const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const { makeProvider } = require('./providers/factory');
const { subscribe, broadcast } = require('./sseHub');
// Pfad ist relativ zu: backend/src/payments/router.js
const { requireFeature } = require('../middleware/subscription');

/**
 * SSE-Stream für Live-Status von Zahlungen.
 * Erwartet ?token=<JWT> (gleiches JWT wie für API-Auth).
 * Diese Route darf VOR der normalen Auth-Kette laufen, daher eigenes Decoding.
 */
router.get('/stream', async (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(401).end();

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.status(401).end();
  }

  const tenantId = payload.tenant_id;
  if (!tenantId) return res.status(401).end();

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(': connected\n\n');

  subscribe(tenantId, res);

  // Keep-alive Ping
  const ping = setInterval(() => {
    try { res.write(': ping\n\n'); } catch {}
  }, 25000);

  req.on('close', () => clearInterval(ping));
});

/**
 * Startet eine Terminalzahlung beim konfigurierten Provider/Terminal.
 * Geschützt über requireFeature('pos') – stelle sicher, dass diese Route
 * NACH auth + tenantContext + loadSubscription eingehängt ist.
 */
router.post('/terminal/charge', requireFeature('pos'), async (req, res, next) => {
  const { amount, currency = 'CHF', provider, terminal_id, metadata } = req.body;

  if (amount == null || Number(amount) <= 0) {
    return res.status(400).json({ error: 'amount must be > 0' });
  }
  try {
    // Provider-Konfiguration laden (entweder konkreter Provider oder active=true)
    const params = provider ? [provider] : [];
    const cfgQ = await req.db.query(
      `SELECT provider, config
         FROM payment_providers
        WHERE tenant_id = current_setting('app.tenant_id')::uuid
          AND (${provider ? 'provider = $1' : 'active = true'})
        ORDER BY active DESC
        LIMIT 1`,
      params
    );
    if (!cfgQ.rowCount) return res.status(400).json({ error: 'No payment provider configured' });

    const { provider: prov, config } = cfgQ.rows[0];

    // Payment anlegen
    const pQ = await req.db.query(
      `INSERT INTO payments (tenant_id, provider, terminal_id, amount, currency, status)
       VALUES (current_setting('app.tenant_id')::uuid, $1, $2, $3, $4, 'in_progress')
       RETURNING id`,
      [prov, terminal_id || null, Number(amount), currency]
    );
    const paymentId = pQ.rows[0].id;

    // Provider starten
    const adapter = makeProvider(prov, config || {}, req.user?.tenantId);
    const result = await adapter.startPayment({
      amount: Number(amount),
      currency,
      terminal_id,
      metadata,
      paymentId,
    });

    await req.db.query(
      `UPDATE payments SET external_id = $2, status = $3 WHERE id = $1`,
      [paymentId, result.externalId || null, result.status || 'in_progress']
    );
    await req.db.query(
      `INSERT INTO payment_events (payment_id, type, payload)
       VALUES ($1, 'started', $2)`,
      [paymentId, result]
    );

    // Live-Update
    broadcast(req.user.tenantId, {
      payment_id: paymentId,
      type: 'started',
      data: result,
    });

    return res.json({
      payment_id: paymentId,
      status: result.status,
      external_id: result.externalId,
    });
  } catch (e) {
    next(e);
  }
});

/**
 * Zahlung abbrechen.
 */
router.post('/terminal/cancel', requireFeature('pos'), async (req, res, next) => {
  const { payment_id } = req.body;
  if (!payment_id) return res.status(400).json({ error: 'payment_id required' });

  try {
    const q = await req.db.query(
      `SELECT provider, external_id
         FROM payments
        WHERE id = $1
          AND tenant_id = current_setting('app.tenant_id')::uuid`,
      [payment_id]
    );
    if (!q.rowCount) return res.status(404).json({ error: 'Payment not found' });

    const { provider, external_id } = q.rows[0];
    const cfg = await req.db.query(
      `SELECT config
         FROM payment_providers
        WHERE tenant_id = current_setting('app.tenant_id')::uuid
          AND provider = $1`,
      [provider]
    );

    const adapter = makeProvider(provider, cfg.rows[0]?.config || {}, req.user?.tenantId);
    await adapter.cancelPayment(external_id);

    await req.db.query(`UPDATE payments SET status = 'cancelled' WHERE id = $1`, [payment_id]);
    await req.db.query(
      `INSERT INTO payment_events (payment_id, type, payload)
       VALUES ($1, 'cancelled', '{}'::jsonb)`,
      [payment_id]
    );

    broadcast(req.user.tenantId, { payment_id, type: 'cancelled' });
    return res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

/**
 * Provider-Callback (z. B. Wallee/Worldline Cloud).
 * Tipp: Wenn dein Provider keine Auth senden kann, hänge diese Route VOR die Auth-Kette ein
 * und valide hier Signaturen (HMAC/Zertifikate). Unten ein generischer Handler.
 */
router.post('/callback/:provider', async (req, res, next) => {
  const { provider } = req.params;
  try {
    // TODO: provider-spezifische Signaturprüfung
    const { external_id, status, payment_id, details } = req.body || {};

    // Payment via payment_id ODER external_id finden
    let id = payment_id;
    let tenantId;
    if (!id && external_id) {
      const r = await req.db.query(
        `SELECT id, tenant_id FROM payments WHERE external_id = $1 LIMIT 1`,
        [external_id]
      );
      if (!r.rowCount) return res.status(404).json({ error: 'payment not found' });
      id = r.rows[0].id;
      tenantId = r.rows[0].tenant_id;
    }

    if (!id) return res.status(400).json({ error: 'missing identifiers' });
    await req.db.query(`UPDATE payments SET status = $2 WHERE id = $1`, [id, status]);

    await req.db.query(
      `INSERT INTO payment_events (payment_id, type, payload)
       VALUES ($1, 'provider_update', $2)`,
      [id, details || { provider }]
    );

    if (!tenantId) {
      const t = await req.db.query(`SELECT tenant_id FROM payments WHERE id = $1`, [id]);
      tenantId = t.rows[0].tenant_id;
    }

    broadcast(tenantId, {
      payment_id: id,
      type: 'status',
      data: { status, provider, external_id },
    });

    return res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

module.exports = router;
