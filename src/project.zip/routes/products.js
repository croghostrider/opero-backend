'use strict';

const express = require('express');
const router = express.Router();

// Alle Routen erwarten, dass auth + tenantContext vorher gelaufen sind
// und dass entweder RLS per current_setting('app.tenant_id') aktiv ist
// ODER wir den tenant_id in WHERE benutzen.

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}
function isNumberLike(v) {
  return typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
}

// LIST
router.get('/', async (req, res, next) => {
    const client = req.db;
  if (!client) {
    // Harte Absicherung: Wenn tenantContext nicht läuft, keine ungefilterten Queries!
    return res.status(500).json({ error: 'Tenant context DB client missing' });
  }
  /*
    #swagger.tags = ['Products']
    #swagger.summary = 'Alle Produkte abrufen'
    #swagger.description = 'Gibt eine Liste aller Produkte des aktuellen Mandanten zurück.'
    #swagger.responses[200] = {
      description: 'Liste der Produkte',
      content: {
        "application/json": {
          schema: {
            type: 'array',
            items: { $ref: '#/components/schemas/Product' }
          }
        }
      }
    }
    #swagger.responses[401] = {
      description: 'Unauthorized',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[500] = { description: 'Internal Server Error' }
  */
  try {
    // Wenn RLS aktiv ist, reicht ein einfaches SELECT *
    const { rows } = await client.query(
      `SELECT id, name, vat_rate, price, created_at
         FROM products
        ORDER BY created_at DESC`
    );
    // 204, wenn leer? Für APIs meist okay, 200 mit [] ist praktikabler:
    return res.status(200).json(rows);
  } catch (e) {
    return next(e);
  }
});

// CREATE
router.post('/', async (req, res, next) => {
    const client = req.db;
  if (!client) {
    // Harte Absicherung: Wenn tenantContext nicht läuft, keine ungefilterten Queries!
    return res.status(500).json({ error: 'Tenant context DB client missing' });
  }
  /*
    #swagger.tags = ['Products']
    #swagger.summary = 'Neues Produkt anlegen'
    #swagger.description = 'Legt ein neues Produkt für den aktuellen Mandanten an.'
    #swagger.requestBody = {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: 'object',
            required: ['name'],
            properties: {
              name:     { type: 'string', example: 'Pizza Margherita' },
              price:    { type: 'number', minimum: 0, example: 12.5 },
              vat_rate: { type: 'number', minimum: 0, example: 2.6 }
            }
          }
        }
      }
    }
    #swagger.responses[201] = {
      description: 'Produkt erfolgreich erstellt',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Product' } } }
    }
    #swagger.responses[400] = {
      description: 'Bad Request (Validierungsfehler oder fehlende Felder)',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[401] = { description: 'Unauthorized' }
    #swagger.responses[500] = { description: 'Internal Server Error' }
  */
  try {
    const { name, price, vat_rate } = req.body || {};

    // Validierung
    if (!isNonEmptyString(name)) {
      return res.status(400).json({ error: 'name is required (non-empty string)' });
    }
    let priceNum = 0;
    if (price !== undefined) {
      if (!isNumberLike(price)) {
        return res.status(400).json({ error: 'price must be a number' });
      }
      priceNum = Number(price);
      if (priceNum < 0) return res.status(400).json({ error: 'price must be >= 0' });
    }
    let vatNum = 0;
    if (vat_rate !== undefined) {
      if (!isNumberLike(vat_rate)) {
        return res.status(400).json({ error: 'vat_rate must be a number' });
      }
      vatNum = Number(vat_rate);
      if (vatNum < 0) return res.status(400).json({ error: 'vat_rate must be >= 0' });
    }

    const insert = await client.query(
      `INSERT INTO products (tenant_id, name, vat_rate, price)
       VALUES (current_setting('app.tenant_id')::uuid, $1, $2, $3)
       RETURNING id, name, vat_rate, price, created_at`,
      [name.trim(), vatNum, priceNum]
    );

    return res.status(201).json(insert.rows[0]);
  } catch (e) {
    // Postgres NOT NULL violation → 400 statt 500
    if (e && e.code === '23502') {
      return res.status(400).json({ error: 'missing required field(s)' });
    }
    return next(e);
  }
});

// UPDATE (partial)
router.put('/:id', async (req, res, next) => {
    const client = req.db;
  if (!client) {
    // Harte Absicherung: Wenn tenantContext nicht läuft, keine ungefilterten Queries!
    return res.status(500).json({ error: 'Tenant context DB client missing' });
  }
  /*
    #swagger.tags = ['Products']
    #swagger.summary = 'Produkt ändern'
    #swagger.description = 'Teilweises Aktualisieren eines Produkts (nur übergebene Felder werden geändert).'
    #swagger.parameters['id'] = {
      in: 'path',
      description: 'Produkt-ID (UUID)',
      required: true,
      schema: { type: 'string', format: 'uuid' }
    }
    #swagger.requestBody = {
      required: true,
      content: {
        "application/json": {
          schema: {
            type: 'object',
            properties: {
              name:     { type: 'string', example: 'Pizza Funghi' },
              price:    { type: 'number', minimum: 0, example: 14.9 },
              vat_rate: { type: 'number', minimum: 0, example: 2.6 }
            }
          }
        }
      }
    }
    #swagger.responses[200] = {
      description: 'OK',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Product' } } }
    }
    #swagger.responses[400] = {
      description: 'Bad Request (keine änderbaren Felder oder ungültige Werte)',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[401] = { description: 'Unauthorized' }
    #swagger.responses[404] = {
      description: 'Not Found',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[500] = { description: 'Internal Server Error' }
  */
  try {
    const { id } = req.params;
    const { name, price, vat_rate } = req.body || {};

    const fields = [];
    const values = [];
    let idx = 1;

    if (name !== undefined) {
      if (!isNonEmptyString(name)) {
        return res.status(400).json({ error: 'name must be a non-empty string' });
      }
      fields.push(`name = $${idx++}`);
      values.push(name.trim());
    }
    if (price !== undefined) {
      if (!isNumberLike(price)) return res.status(400).json({ error: 'price must be a number' });
      const n = Number(price);
      if (n < 0) return res.status(400).json({ error: 'price must be >= 0' });
      fields.push(`price = $${idx++}`);
      values.push(n);
    }
    if (vat_rate !== undefined) {
      if (!isNumberLike(vat_rate)) return res.status(400).json({ error: 'vat_rate must be a number' });
      const n = Number(vat_rate);
      if (n < 0) return res.status(400).json({ error: 'vat_rate must be >= 0' });
      fields.push(`vat_rate = $${idx++}`);
      values.push(n);
    }

    if (fields.length === 0) {
      return res.status(400).json({ error: 'no updatable fields provided' });
    }

    values.push(id);
    const { rows } = await client.query(
      `UPDATE products
          SET ${fields.join(', ') }
        WHERE id = $${idx}
          -- Wenn du RLS nicht nutzt, zusätzlich Tenant-Schutz:
          -- AND tenant_id = current_setting('app.tenant_id')::uuid
        RETURNING id, name, vat_rate, price, created_at`,
      values
    );

    if (rows.length === 0) return res.status(404).json({ error: 'not found' });
    return res.status(200).json(rows[0]);
  } catch (e) {
    return next(e);
  }
});

// DELETE
router.delete('/:id', async (req, res, next) => {
  const client = req.db;
  if (!client) {
    // Harte Absicherung: Wenn tenantContext nicht läuft, keine ungefilterten Queries!
    return res.status(500).json({ error: 'Tenant context DB client missing' });
  }
  /*
    #swagger.tags = ['Products']
    #swagger.summary = 'Produkt löschen'
    #swagger.parameters['id'] = {
      in: 'path',
      description: 'Produkt-ID (UUID)',
      required: true,
      schema: { type: 'string', format: 'uuid' }
    }
    #swagger.responses[204] = { description: 'No Content' }
    #swagger.responses[401] = {
      description: 'Unauthorized',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[404] = {
      description: 'Not Found',
      content: { "application/json": { schema: { $ref: '#/components/schemas/Error' } } }
    }
    #swagger.responses[500] = { description: 'Internal Server Error' }
  */
  try {
    const { id } = req.params;
    const r = await client.query(
      `DELETE FROM products
        WHERE id = $1
        -- AND tenant_id = current_setting('app.tenant_id')::uuid
        RETURNING id`,
      [id]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'not found' });
    return res.status(204).send();
  } catch (e) {
    return next(e);
  }
});

module.exports = router;
